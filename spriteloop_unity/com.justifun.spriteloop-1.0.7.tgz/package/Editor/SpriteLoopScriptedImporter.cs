using System.IO;
using UnityEditor.AssetImporters;
using UnityEngine;

namespace Justifun.SpriteLoop.Editor
{
    /// <summary>Imports .spla ZIP bytes as an assignable SpriteLoopAsset.</summary>
    [ScriptedImporter(1, "spla")]
    public sealed class SpriteLoopScriptedImporter : ScriptedImporter
    {
        public override void OnImportAsset(AssetImportContext context)
        {
            var asset = ScriptableObject.CreateInstance<SpriteLoopAsset>();
            asset.name = Path.GetFileNameWithoutExtension(context.assetPath);
            asset.SetBytes(File.ReadAllBytes(context.assetPath));
            context.AddObjectToAsset("SpriteLoop Package", asset);
            context.SetMainObject(asset);
        }
    }
}

