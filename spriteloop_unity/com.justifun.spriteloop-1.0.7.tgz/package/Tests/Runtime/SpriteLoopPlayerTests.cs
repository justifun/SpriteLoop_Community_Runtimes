using System;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace Justifun.SpriteLoop.Tests
{
    public sealed class SpriteLoopPlayerTests
    {
        private const string PNG_BASE64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAANSURBVBhXY/j///9/AAn7A/0FQ0XKAAAAAElFTkSuQmCC";

        [Test]
        public void LoadsPlaysSkinsVariantsAndEvents()
        {
            var playerObj = new GameObject("SpriteLoop Test");
            try
            {
                var player = playerObj.AddComponent<SpriteLoopPlayer>();
                Assert.That(player.Load(CreatePackage()), Is.True);
                Assert.That(player.IsLoaded, Is.True);
                Assert.That(player.PackageName, Is.EqualTo("unit"));
                Assert.That(player.AnimationCount, Is.EqualTo(1));
                Assert.That(player.PartCount, Is.EqualTo(3));
                Assert.That(player.CurrentAnimationId, Is.EqualTo("idle"));
                Assert.That(player.TryGetPartTransform("body", out var partTransform), Is.True);
                Assert.That(partTransform.localPosition.sqrMagnitude, Is.LessThan(0.000001f));
                var renderers = player.GetComponentsInChildren<MeshRenderer>(true);
                Assert.That(renderers, Has.Length.EqualTo(1));
                Assert.That(player.GetComponentsInChildren<MeshFilter>(true), Has.Length.EqualTo(1));
                Assert.That(renderers[0].sharedMaterials, Has.Length.EqualTo(1));
                Assert.That(renderers[0].sharedMaterial.mainTexture, Is.Not.Null);
                Assert.That(renderers[0].GetComponent<MeshFilter>().sharedMesh.vertexCount, Is.EqualTo(12));
                Assert.That(renderers[0].GetComponent<MeshFilter>().sharedMesh.GetIndexCount(0), Is.EqualTo(18));

                var eventCount = 0;
                player.AnimationEvent += animationEvent =>
                {
                    eventCount++;
                    Assert.That(animationEvent.Name, Is.EqualTo("step"));
                    Assert.That(animationEvent.Data, Is.EqualTo("unit-test"));
                };
                player.SetFrame(1, true);
                Assert.That(partTransform.localPosition.x, Is.EqualTo(0.1f).Within(0.0001f));
                Assert.That(eventCount, Is.EqualTo(1));
                Assert.That(player.SetSkin("blue"), Is.True);
                Assert.That(player.CurrentSkinId, Is.EqualTo("blue"));
                Assert.That(player.SetVariant("body", "alternate"), Is.True);
                Assert.That(player.ClearVariant("body"), Is.True);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(playerObj);
            }
        }

        [Test]
        public void ControlTransformsSupportOffsetAndAbsoluteOverrides()
        {
            var playerObj = new GameObject("SpriteLoop Control Override Test");
            try
            {
                var player = playerObj.AddComponent<SpriteLoopPlayer>();
                Assert.That(player.Load(CreatePackage()), Is.True);
                Assert.That(player.SetControlPosition("body", new Vector2(10f, -5f)), Is.True);
                Assert.That(player.SetControlAngle("body", 15f), Is.True);
                Assert.That(player.SetControlScale("body", new Vector2(2f, 0.5f)), Is.True);
                Assert.That(player.TryGetControlTransformState("body", out var state), Is.True);
                Assert.That(state.AuthoredPosition, Is.EqualTo(new Vector2(50f, 50f)));
                Assert.That(state.FinalPosition, Is.EqualTo(new Vector2(60f, 45f)));
                Assert.That(state.FinalAngle, Is.EqualTo(15f));
                Assert.That(state.FinalScale, Is.EqualTo(new Vector2(2f, 0.5f)));
                Assert.That(player.TryGetPartTransform("body", out var partTransform), Is.True);
                Assert.That(partTransform.localPosition, Is.EqualTo(new Vector3(0.1f, 0.05f, 0f)));
                Assert.That(Mathf.DeltaAngle(partTransform.localEulerAngles.z, -15f), Is.EqualTo(0f).Within(0.001f));
                Assert.That(partTransform.localScale, Is.EqualTo(new Vector3(2f, 0.5f, 1f)));

                player.SetFrame(1);
                Assert.That(player.TryGetControlTransformState("body", out state), Is.True);
                Assert.That(state.AuthoredPosition, Is.EqualTo(new Vector2(60f, 50f)));
                Assert.That(state.FinalPosition, Is.EqualTo(new Vector2(70f, 45f)));

                Assert.That(player.SetControlPosition("body", new Vector2(25f, 75f), SpriteLoopTransformOverrideMode.ABSOLUTE), Is.True);
                Assert.That(player.SetControlAngle("body", -20f, SpriteLoopTransformOverrideMode.ABSOLUTE), Is.True);
                Assert.That(player.SetControlScale("body", new Vector2(3f, 4f), SpriteLoopTransformOverrideMode.ABSOLUTE), Is.True);
                Assert.That(player.TryGetControlTransformState("body", out state), Is.True);
                Assert.That(state.PositionMode, Is.EqualTo(SpriteLoopTransformOverrideMode.ABSOLUTE));
                Assert.That(state.FinalPosition, Is.EqualTo(new Vector2(25f, 75f)));
                Assert.That(state.FinalAngle, Is.EqualTo(-20f));
                Assert.That(state.FinalScale, Is.EqualTo(new Vector2(3f, 4f)));
                Assert.That(partTransform.localPosition, Is.EqualTo(new Vector3(-0.25f, -0.25f, 0f)));

                Assert.That(player.ClearControlOverride("body"), Is.True);
                Assert.That(player.TryGetControlTransformState("body", out state), Is.True);
                Assert.That(state.HasPositionOverride, Is.False);
                Assert.That(state.FinalPosition, Is.EqualTo(state.AuthoredPosition));
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(playerObj);
            }
        }

        [Test]
        public void RejectsInvalidArchiveBytes()
        {
            var playerObj = new GameObject("SpriteLoop Invalid Test");
            try
            {
                var player = playerObj.AddComponent<SpriteLoopPlayer>();
                LogAssert.Expect(LogType.Error, new Regex("SpriteLoop could not load:"));
                Assert.That(player.Load(new byte[] { 1, 2, 3 }), Is.False);
                Assert.That(player.IsLoaded, Is.False);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(playerObj);
            }
        }

        [Test]
        public void EditorPreviewLoadsFirstFrameWithoutSavingGeneratedObjects()
        {
            var playerObj = new GameObject("SpriteLoop Preview Test");
            var asset = ScriptableObject.CreateInstance<SpriteLoopAsset>();
            try
            {
                asset.SetBytes(CreatePackage());
                var player = playerObj.AddComponent<SpriteLoopPlayer>();
                typeof(SpriteLoopPlayer).GetField("_package", BindingFlags.Instance | BindingFlags.NonPublic)?.SetValue(player, asset);
                player.SendMessage("OnValidate");
                player.SendMessage("Update");

                Assert.That(player.IsLoaded, Is.True);
                Assert.That(player.Frame, Is.EqualTo(0));
                Assert.That(player.IsPlaying, Is.False);
                var renderer = player.GetComponentInChildren<MeshRenderer>(true);
                Assert.That(renderer, Is.Not.Null);
                Assert.That(renderer.sharedMaterial.hideFlags, Is.EqualTo(HideFlags.HideAndDontSave));
                Assert.That(renderer.sharedMaterial.mainTexture.hideFlags, Is.EqualTo(HideFlags.HideAndDontSave));
                Assert.That(renderer.GetComponent<MeshFilter>().sharedMesh.hideFlags, Is.EqualTo(HideFlags.HideAndDontSave));
                Assert.That(renderer.gameObject.hideFlags, Is.EqualTo(HideFlags.HideAndDontSave));
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(playerObj);
                UnityEngine.Object.DestroyImmediate(asset);
            }
        }

        private static byte[] CreatePackage()
        {
            const string manifest = "{\"format\":\"spla\",\"version\":1,\"name\":\"unit\",\"canvas\":{\"width\":100,\"height\":100},\"parts\":[{\"id\":\"p\",\"key\":\"body\",\"name\":\"Body\",\"asset\":\"assets/body.png\",\"width\":1,\"height\":1,\"pivot\":{\"x\":0.5,\"y\":0.5},\"drawOrder\":0,\"visible\":true},{\"id\":\"p2\",\"key\":\"scarf\",\"name\":\"Scarf\",\"asset\":\"assets/body.png\",\"width\":1,\"height\":1,\"pivot\":{\"x\":0.5,\"y\":0.5},\"drawOrder\":1,\"visible\":true},{\"id\":\"p3\",\"key\":\"hat\",\"name\":\"Hat\",\"asset\":\"assets/body.png\",\"width\":1,\"height\":1,\"pivot\":{\"x\":0.5,\"y\":0.5},\"drawOrder\":2,\"visible\":true}],\"variants\":[{\"id\":\"v\",\"key\":\"alternate\",\"name\":\"Alternate\",\"part\":\"p\",\"asset\":\"assets/alternate.png\",\"width\":1,\"height\":1}],\"states\":[{\"id\":\"state_alt\",\"key\":\"alt\",\"name\":\"Alternate State\",\"part\":\"p\"}],\"skins\":[{\"id\":\"default\",\"name\":\"Default\",\"parts\":{\"p\":{\"states\":{\"state_alt\":\"v\"}}}},{\"id\":\"blue\",\"name\":\"Blue\",\"parts\":{\"p\":{\"variant\":\"v\"}}}],\"animations\":[{\"id\":\"idle\",\"name\":\"Idle\",\"fps\":2,\"loop\":true,\"frames\":[{\"index\":0,\"sourceFrame\":0,\"parts\":[{\"part\":\"p\",\"x\":50,\"y\":50,\"scaleX\":1,\"scaleY\":1,\"opacity\":1},{\"part\":\"p2\",\"x\":50,\"y\":48,\"scaleX\":1,\"scaleY\":1,\"opacity\":1},{\"part\":\"p3\",\"x\":50,\"y\":46,\"scaleX\":1,\"scaleY\":1,\"opacity\":1}]},{\"index\":1,\"sourceFrame\":1,\"parts\":[{\"part\":\"p\",\"x\":60,\"y\":50,\"scaleX\":1,\"scaleY\":1,\"opacity\":1,\"state\":{\"current\":\"alt\",\"next\":\"alt\",\"mix\":0.25}},{\"part\":\"p2\",\"x\":50,\"y\":48,\"scaleX\":1,\"scaleY\":1,\"opacity\":1},{\"part\":\"p3\",\"x\":50,\"y\":46,\"scaleX\":1,\"scaleY\":1,\"opacity\":1}],\"events\":[{\"name\":\"step\",\"data\":\"unit-test\"}]}]}]}";
            using (var output = new MemoryStream())
            {
                using (var archive = new ZipArchive(output, ZipArchiveMode.Create, true))
                {
                    WriteEntry(archive, "manifest.json", Encoding.UTF8.GetBytes(manifest));
                    var png = Convert.FromBase64String(PNG_BASE64);
                    WriteEntry(archive, "assets/body.png", png);
                    WriteEntry(archive, "assets/alternate.png", png);
                }
                return output.ToArray();
            }
        }

        private static void WriteEntry(ZipArchive archive, string name, byte[] bytes)
        {
            var entry = archive.CreateEntry(name, System.IO.Compression.CompressionLevel.NoCompression);
            using (var stream = entry.Open())
                stream.Write(bytes, 0, bytes.Length);
        }
    }
}
