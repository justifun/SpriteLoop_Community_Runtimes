# SpriteLoop Animation Controls for Unity

This guide covers the basic runtime controls provided by `SpriteLoopPlayer`: playing, pausing, resuming, stopping, changing animations, overriding looping, changing speed, seeking, and receiving animation events.

## Setup

1. Add `SpriteLoopPlayer` to a GameObject.
2. Assign an imported `SpriteLoopAsset` to its **Package** field.
3. Enable **Load On Start**.
4. Reference the player from your gameplay script with `using Justifun.SpriteLoop;`.

Animation references can be an animation ID or display name. Matching is case-insensitive. `Play` returns `false` when the package is not loaded or the animation cannot be found.

## Play an animation

```csharp
using Justifun.SpriteLoop;
using UnityEngine;

/// <summary>Provides a simple Idle animation command.</summary>
public sealed class CharacterAnimation : MonoBehaviour
{
    [Tooltip("SpriteLoop player controlled by this component.")]
    [SerializeField] private SpriteLoopPlayer _player;

    public void PlayIdle()
    {
        _player.Play("idle");
    }
}
```

When a package loads asynchronously, wait for its `Loaded` event:

```csharp
private void OnEnable()
{
    // Play now when loaded, or wait for the package to finish loading.
    _player.Loaded += PlayIdle;
    if (_player.IsLoaded)
        PlayIdle();
}

private void OnDisable()
{
    // Stop receiving package load callbacks while disabled.
    _player.Loaded -= PlayIdle;
}
```

## Pause, resume, and stop

```csharp
_player.Pause();
_player.Resume();
_player.Stop();
```

`Pause` and `Stop` both leave the current frame visible. `Resume` continues from a paused frame. To restart the current animation from frame zero, call `Play` again with its default `restart` value of `true`:

```csharp
_player.Play(_player.CurrentAnimationId);
```

A simple pause toggle is:

```csharp
if (_player.IsPaused)
    _player.Resume();
else
    _player.Pause();
```

## Change animations

```csharp
_player.Play("idle");
_player.Play("walk");
_player.Play("attack");
```

Changing to another animation starts it from frame zero. To continue the currently selected animation without restarting it, pass `restart: false`:

```csharp
_player.Play(_player.CurrentAnimationId, SpriteLoopLoopMode.FROM_PACKAGE, restart: false);
```

## Override looping

```csharp
// Use the loop setting exported in the .spla package.
_player.Play("idle", SpriteLoopLoopMode.FROM_PACKAGE);

// Force an animation to loop.
_player.Play("walk", SpriteLoopLoopMode.LOOP);

// Force a one-shot animation.
_player.Play("attack", SpriteLoopLoopMode.NO_LOOP);
```

`AnimationFinished` is raised when a non-looping animation reaches its end.

## Change playback speed

```csharp
_player.PlaybackRate = 0.5f; // Half speed
_player.PlaybackRate = 1f;   // Normal speed
_player.PlaybackRate = 2f;   // Double speed
```

## Seek to a frame or time

```csharp
_player.SetFrame(12);
_player.SetTime(0.5f);
```

Both methods clamp to the current animation. Pass `true` as the second argument when the destination frame's authored events should be emitted:

```csharp
_player.SetFrame(12, emitEvents: true);
```

## Read playback state

```csharp
Debug.Log(_player.IsPlaying);
Debug.Log(_player.IsPaused);
Debug.Log(_player.CurrentAnimationId);
Debug.Log(_player.Frame);
Debug.Log(_player.PlaybackTime);
```

## Listen for animation events

```csharp
private void OnEnable()
{
    // Listen for playback and authored frame events while enabled.
    _player.AnimationLooped += OnAnimationLooped;
    _player.AnimationFinished += OnAnimationFinished;
    _player.AnimationEvent += OnAnimationEvent;
}

private void OnDisable()
{
    // Remove every subscription made when enabled.
    _player.AnimationLooped -= OnAnimationLooped;
    _player.AnimationFinished -= OnAnimationFinished;
    _player.AnimationEvent -= OnAnimationEvent;
}

private void OnAnimationLooped(string animationId)
{
    Debug.Log($"Looped: {animationId}");
}

private void OnAnimationFinished(string animationId)
{
    Debug.Log($"Finished: {animationId}");
}

private void OnAnimationEvent(SpriteLoopAnimationEvent animationEvent)
{
    Debug.Log($"{animationEvent.Name}: {animationEvent.Data}");
}
```

## Importable controller sample

The package includes an **Animation Controls** sample containing `BasicSpriteLoopAnimationControls`. Import it from the package's **Samples** section and attach it to the same GameObject as `SpriteLoopPlayer`. Its public methods can be connected directly to Unity UI Button `On Click` events.
