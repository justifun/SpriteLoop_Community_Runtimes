# SpriteLoop Performance for Unity

The current player is designed around one dynamic mesh per character. All visible parts are packed into one atlas and submitted through one `MeshRenderer` and one material. Vertex, UV, color, and index arrays are reused, and the mesh is updated only when the authored animation frame changes.

## Construct optimization comparison

| Construct improvement | Unity status | Unity equivalent |
|---|---|---|
| Pack every character part into one texture atlas | Already implemented | One atlas, material, mesh, and renderer per player |
| Redraw only when the authored frame changes | Already implemented | `ApplyFrame` runs only when the frame, skin, or variant changes |
| Share parsed packages and GPU textures between instances | Not implemented yet | Bake imported data once and share atlas/material data from `SpriteLoopAsset` |
| Coordinate display-rate redraw requests | Not applicable | Unity controls camera rendering independently; suppressing renderer updates would not raise the reported frame rate |

The shared-data optimization would primarily improve load time and memory, just as it did in Construct. It may not materially increase steady-state frame rate when rendering is already the bottleneck.

## Recommended next improvements

### 1. Bake packages during asset import

Highest priority. Expand the scripted importer so it parses the manifest, decodes images, builds the atlas, and stores runtime-ready metadata and texture sub-assets in `SpriteLoopAsset`. Players would no longer unzip, decode PNGs, parse JSON, or call `PackTextures` at startup.

Benefits:

- one imported atlas shared by every instance;
- substantially lower repeated-instance memory use;
- much faster scene startup and editor preview creation;
- Unity texture compression, platform overrides, and mipmap/filter settings can be applied during import;
- player builds do not need runtime ZIP and image-decoding work for project assets.

Keep the existing byte and StreamingAssets loading paths for downloadable or user-created packages.

### 2. Add off-screen animation policies

Expose an option similar to Animator culling:

- **Always animate**: current behavior; events and visuals remain exact.
- **Events only while off-screen**: advance time and events but skip mesh uploads.
- **Pause while off-screen**: skip all work until visible again.

This can significantly reduce CPU work for crowds outside all cameras. The policy must be explicit because pausing can affect gameplay events.

### 3. Share meshes by frame and appearance

For large crowds using the same package, animation, frame, skin, and variant selection, cache one immutable mesh for that combination. Five hundred randomly phased instances of a 30-frame animation could reuse about 30 meshes instead of uploading 500 independent meshes.

A custom instancing-compatible shader plus `Graphics.RenderMeshInstanced`, `BatchRendererGroup`, or Entities Graphics could then collapse identical combinations into instanced draws. This is the largest potential steady-state rendering gain, but it changes the renderer architecture and should follow profiler measurements.

### 4. Make part attachment transforms optional

The current player creates one helper GameObject per authored part so `TryGetPartTransform` can return a real `Transform`. Characters that never attach weapons, effects, or other objects still pay the hierarchy and transform-update cost. An option to generate only requested attachment transforms would reduce GameObject and Transform counts in large crowds.

### 5. Use advanced mesh upload APIs

Set a conservative fixed mesh bound from the SpriteLoop canvas, then update buffers with `Mesh.SetVertexBufferData`, `Mesh.SetIndexBufferData`, and safe `MeshUpdateFlags`. This can avoid per-frame bounds recalculation, validation, and some managed-to-native copying. It is a smaller gain than import baking, culling, or mesh sharing.

### 6. Jobs and Burst only after profiling

Part-to-vertex transform math can move to Burst jobs, but the current workload per character is small. Job scheduling overhead can exceed the saved math unless character and part counts are high. Profile the main thread, render thread, batches, and mesh upload time before adding this complexity.

