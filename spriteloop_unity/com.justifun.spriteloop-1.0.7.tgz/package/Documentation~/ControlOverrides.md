# SpriteLoop Runtime Control Overrides for Unity

Every exported image part or empty control part can receive persistent position, angle, and scale overrides. Each channel can independently modify the authored animation or replace it completely.

```csharp
using Justifun.SpriteLoop;
using UnityEngine;

/// <summary>Procedurally offsets a SpriteLoop weapon control.</summary>
public sealed class AimSpriteLoopControl : MonoBehaviour
{
    [Tooltip("SpriteLoop player to adjust.")]
    [SerializeField] private SpriteLoopPlayer _player;

    private void Update()
    {
        // Offset uses SpriteLoop canvas pixels, degrees, and scale multipliers.
        _player.SetControlPosition("weapon_control", new Vector2(8f, -3f));
        _player.SetControlAngle("weapon_control", 20f);
        _player.SetControlScale("weapon_control", new Vector2(1.1f, 1.1f));
    }
}
```

Pass `SpriteLoopTransformOverrideMode.ABSOLUTE` to replace the authored channel:

```csharp
player.SetControlPosition("head_control", new Vector2(128f, 72f),
    SpriteLoopTransformOverrideMode.ABSOLUTE);
player.SetControlAngle("head_control", 0f,
    SpriteLoopTransformOverrideMode.ABSOLUTE);
player.SetControlScale("head_control", Vector2.one,
    SpriteLoopTransformOverrideMode.ABSOLUTE);
```

Absolute positions are measured from the SpriteLoop canvas top-left. The generated Unity attachment `Transform` remains centered on the character and converted through **Pixels Per Unit**.

Position, angle, and scale modes are independent. Setting an absolute position does not change an existing angle offset. Overrides persist across frames and animation changes until cleared or until another package is loaded.

```csharp
player.ClearControlOverride("head_control");
player.ClearControlOverrides();
```

Query authored, stored override, and final canvas values with:

```csharp
if (player.TryGetControlTransformState("weapon_control", out var state))
{
    Debug.Log(state.AuthoredPosition);
    Debug.Log(state.PositionMode);
    Debug.Log(state.PositionOverride);
    Debug.Log(state.FinalPosition);
    Debug.Log(state.FinalAngle);
    Debug.Log(state.FinalScale);
}
```

`TryGetPartTransform` returns the generated Unity `Transform` after overrides are applied. Parenting an object to that transform makes it follow the final animated control.
