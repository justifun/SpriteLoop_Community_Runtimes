using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;
using UnityEngine.Networking;

namespace Justifun.SpriteLoop
{
    public enum SpriteLoopLoopMode
    {
        FROM_PACKAGE,
        LOOP,
        NO_LOOP
    }

    /// <summary>Controls whether a runtime transform value modifies or replaces authored animation data.</summary>
    public enum SpriteLoopTransformOverrideMode
    {
        OFFSET,
        ABSOLUTE
    }

    /// <summary>Describes one control's authored, overridden, and final SpriteLoop canvas transform.</summary>
    public readonly struct SpriteLoopControlTransformState
    {
        public Vector2 AuthoredPosition { get; }
        public float AuthoredAngle { get; }
        public Vector2 AuthoredScale { get; }
        public bool HasPositionOverride { get; }
        public SpriteLoopTransformOverrideMode PositionMode { get; }
        public Vector2 PositionOverride { get; }
        public bool HasAngleOverride { get; }
        public SpriteLoopTransformOverrideMode AngleMode { get; }
        public float AngleOverride { get; }
        public bool HasScaleOverride { get; }
        public SpriteLoopTransformOverrideMode ScaleMode { get; }
        public Vector2 ScaleOverride { get; }
        public Vector2 FinalPosition { get; }
        public float FinalAngle { get; }
        public Vector2 FinalScale { get; }

        internal SpriteLoopControlTransformState(Vector2 authoredPosition, float authoredAngle, Vector2 authoredScale,
            PartTransformOverrideRuntime transformOverride)
        {
            AuthoredPosition = authoredPosition;
            AuthoredAngle = authoredAngle;
            AuthoredScale = authoredScale;
            HasPositionOverride = transformOverride != null && transformOverride.HasPosition;
            PositionMode = transformOverride?.PositionMode ?? SpriteLoopTransformOverrideMode.OFFSET;
            PositionOverride = transformOverride?.Position ?? Vector2.zero;
            HasAngleOverride = transformOverride != null && transformOverride.HasAngle;
            AngleMode = transformOverride?.AngleMode ?? SpriteLoopTransformOverrideMode.OFFSET;
            AngleOverride = transformOverride?.Angle ?? 0f;
            HasScaleOverride = transformOverride != null && transformOverride.HasScale;
            ScaleMode = transformOverride?.ScaleMode ?? SpriteLoopTransformOverrideMode.OFFSET;
            ScaleOverride = transformOverride?.Scale ?? Vector2.one;
            FinalPosition = !HasPositionOverride ? authoredPosition : PositionMode == SpriteLoopTransformOverrideMode.ABSOLUTE
                ? PositionOverride
                : authoredPosition + PositionOverride;
            FinalAngle = !HasAngleOverride ? authoredAngle : AngleMode == SpriteLoopTransformOverrideMode.ABSOLUTE
                ? AngleOverride
                : authoredAngle + AngleOverride;
            FinalScale = !HasScaleOverride ? authoredScale : ScaleMode == SpriteLoopTransformOverrideMode.ABSOLUTE
                ? ScaleOverride
                : Vector2.Scale(authoredScale, ScaleOverride);
        }
    }

    /// <summary>Authored event emitted when playback enters a SpriteLoop frame.</summary>
    public readonly struct SpriteLoopAnimationEvent
    {
        public string AnimationId { get; }
        public int Frame { get; }
        public int SourceFrame { get; }
        public string Name { get; }
        public string Data { get; }

        public SpriteLoopAnimationEvent(string animationId, int frame, int sourceFrame, string name, string data)
        {
            AnimationId = animationId;
            Frame = frame;
            SourceFrame = sourceFrame;
            Name = name;
            Data = data;
        }
    }

    /// <summary>Stores optional runtime transform channels for one SpriteLoop control.</summary>
    internal sealed class PartTransformOverrideRuntime
    {
        public bool HasPosition { get; set; }
        public SpriteLoopTransformOverrideMode PositionMode { get; set; }
        public Vector2 Position { get; set; }
        public bool HasAngle { get; set; }
        public SpriteLoopTransformOverrideMode AngleMode { get; set; }
        public float Angle { get; set; }
        public bool HasScale { get; set; }
        public SpriteLoopTransformOverrideMode ScaleMode { get; set; }
        public Vector2 Scale { get; set; } = Vector2.one;
    }

    /// <summary>Loads SPLA v1 archives and renders their multipart animations with Unity meshes.</summary>
    [ExecuteAlways]
    public sealed class SpriteLoopPlayer : MonoBehaviour
    {
        private static readonly int MAIN_TEXTURE_ID = Shader.PropertyToID("_MainTex");
        private static readonly int COLOR_ID = Shader.PropertyToID("_Color");

        [Header("Package")]
        [Tooltip("A .spla file imported by the SpriteLoop scripted importer.")]
        [SerializeField] private SpriteLoopAsset _package;
        [Tooltip("Optional path relative to StreamingAssets, used when Package is empty.")]
        [SerializeField] private string _streamingAssetsFile = "";
        [Tooltip("Load Package or Streaming Assets File when the scene starts.")]
        [SerializeField] private bool _loadOnStart = true;
        [Tooltip("Display the assigned package's first animation frame in the Scene view while not playing.")]
        [SerializeField] private bool _previewInEditor = true;

        [Header("Playback")]
        [Tooltip("Animation ID or display name. Empty selects the first animation.")]
        [SerializeField] private string _defaultAnimation = "";
        [Tooltip("Start playback after loading.")]
        [SerializeField] private bool _autoplay = true;
        [Tooltip("Initial loop override.")]
        [SerializeField] private SpriteLoopLoopMode _defaultLoopMode = SpriteLoopLoopMode.FROM_PACKAGE;
        [Tooltip("Animation speed multiplier.")]
        [Min(0f)] [SerializeField] private float _playbackRate = 1f;
        [Tooltip("Emit authored events when playback enters their frames.")]
        [SerializeField] private bool _emitEvents = true;

        [Header("Rendering")]
        [Tooltip("SpriteLoop canvas pixels represented by one Unity unit.")]
        [Min(0.0001f)] [SerializeField] private float _pixelsPerUnit = 100f;
        [Tooltip("Unity sorting layer used by generated part renderers.")]
        [SerializeField] private string _sortingLayer = "Default";
        [Tooltip("Added to every authored part draw order.")]
        [SerializeField] private int _sortingOrder;
        [Tooltip("Filtering applied to extracted PNG textures.")]
        [SerializeField] private FilterMode _filterMode = FilterMode.Bilinear;
        [Tooltip("Maximum side length of the runtime atlas used to render the character in one draw call.")]
        [Min(256)] [SerializeField] private int _maximumAtlasSize = 4096;

        private readonly Dictionary<string, int> _animationLookup = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, int> _partLookup = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, int> _skinLookup = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, int> _variantLookup = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, Texture2D> _textures = new Dictionary<string, Texture2D>(StringComparer.Ordinal);
        private readonly Dictionary<int, int> _manualVariants = new Dictionary<int, int>();
        private readonly Dictionary<int, PartTransformOverrideRuntime> _controlOverrides = new Dictionary<int, PartTransformOverrideRuntime>();
        private SplaManifest _manifest;
        private PartRuntime[] _parts = Array.Empty<PartRuntime>();
        private ImageRuntime[] _variants = Array.Empty<ImageRuntime>();
        private SkinRuntime[] _skins = Array.Empty<SkinRuntime>();
        private Material _material;
        private Texture2D _atlas;
        private Mesh _mesh;
        private MeshRenderer _renderer;
        private GameObject _partsRootObj;
        private Vector3[] _vertices = Array.Empty<Vector3>();
        private Vector2[] _uvs = Array.Empty<Vector2>();
        private Color32[] _colors = Array.Empty<Color32>();
        private int[] _triangles = Array.Empty<int>();
        private readonly List<PartRuntime> _drawParts = new List<PartRuntime>();
        private int _animationIndex = -1;
        private int _frameIndex = -1;
        private int _skinIndex;
        private float _elapsed;
        private bool _playing;
        private bool _paused;
        private SpriteLoopLoopMode _loopMode = SpriteLoopLoopMode.FROM_PACKAGE;
#if UNITY_EDITOR
        private bool _editorPreviewDirty;
#endif

        public event Action Loaded;
        public event Action<string> LoadFailed;
        public event Action<int> FrameChanged;
        public event Action<string> AnimationLooped;
        public event Action<string> AnimationFinished;
        public event Action<SpriteLoopAnimationEvent> AnimationEvent;

        public bool IsLoaded => _manifest != null;
        public bool IsPlaying => _playing;
        public bool IsPaused => _paused;
        public string PackageName => _manifest?.Name ?? "";
        public int AnimationCount => _manifest?.Animations?.Length ?? 0;
        public int PartCount => _manifest?.Parts?.Length ?? 0;
        public int Frame => _frameIndex;
        public float PlaybackTime => _elapsed;
        public string CurrentAnimationId => _animationIndex >= 0 ? _manifest.Animations[_animationIndex].Id : "";
        public string CurrentSkinId => _skinIndex >= 0 && _skinIndex < _skins.Length ? _skins[_skinIndex].Id : "";
        public float PlaybackRate { get => _playbackRate; set => _playbackRate = Mathf.Max(0f, value); }
        public bool EmitEvents { get => _emitEvents; set => _emitEvents = value; }

        private void OnEnable()
        {
#if UNITY_EDITOR
            // Build the preview during the next editor update, where object creation is safe.
            if (!Application.IsPlaying(gameObject))
                _editorPreviewDirty = true;
#endif
        }

        private void OnDisable()
        {
#if UNITY_EDITOR
            // Editor previews are transient and must not survive a disabled component.
            if (!Application.IsPlaying(gameObject))
            {
                _editorPreviewDirty = false;
                Unload();
            }
#endif
        }

        private void Start()
        {
            // Load the directly assigned package first, then fall back to StreamingAssets.
            if (!Application.IsPlaying(gameObject))
                return;
            if (!_loadOnStart)
                return;
            if (_package != null)
            {
                Load(_package);
                return;
            }
            if (!string.IsNullOrWhiteSpace(_streamingAssetsFile))
                StartCoroutine(LoadFromStreamingAssets(_streamingAssetsFile));
        }

        private void OnDestroy()
        {
            // Release all runtime-created meshes, textures, and materials.
            Unload();
        }

        private void Update()
        {
#if UNITY_EDITOR
            // Edit Mode displays a static first frame and never runs playback logic.
            if (!Application.IsPlaying(gameObject))
            {
                if (!_editorPreviewDirty)
                    return;
                _editorPreviewDirty = false;
                if (!_previewInEditor || _package == null)
                {
                    Unload();
                    return;
                }
                if (Load(_package))
                {
                    _playing = false;
                    _paused = false;
                }
                return;
            }
#endif
            // Advance authored frames and report every crossed event frame.
            if (!_playing || _manifest == null || _playbackRate <= 0f)
                return;
            var animation = _manifest.Animations[_animationIndex];
            if (animation.Frames.Length == 0)
                return;
            var fps = Mathf.Max(0.0001f, animation.Fps);
            var duration = animation.Frames.Length / fps;
            var nextElapsed = _elapsed + Time.deltaTime * _playbackRate;
            var oldFrame = Mathf.Clamp(Mathf.FloorToInt(_elapsed * fps), 0, animation.Frames.Length - 1);

            if (EffectiveLoop(animation))
            {
                var crossedFrames = Mathf.Max(0, Mathf.FloorToInt(nextElapsed * fps) - Mathf.FloorToInt(_elapsed * fps));
                for (var step = 1; step <= crossedFrames; step++)
                {
                    var enteredFrame = (oldFrame + step) % animation.Frames.Length;
                    if (enteredFrame == 0)
                        AnimationLooped?.Invoke(animation.Id);
                    EmitFrameEvents(animation, enteredFrame);
                }
                _elapsed = Mathf.Repeat(nextElapsed, duration);
                var frame = Mathf.Clamp(Mathf.FloorToInt(_elapsed * fps), 0, animation.Frames.Length - 1);
                if (frame != _frameIndex)
                    ApplyFrame(frame, false);
                return;
            }

            _elapsed = Mathf.Min(nextElapsed, duration);
            var nextFrame = Mathf.Clamp(Mathf.FloorToInt(_elapsed * fps), 0, animation.Frames.Length - 1);
            for (var frame = oldFrame + 1; frame <= nextFrame; frame++)
                EmitFrameEvents(animation, frame);
            if (nextFrame != _frameIndex)
                ApplyFrame(nextFrame, false);
            if (nextElapsed < duration)
                return;
            _playing = false;
            _paused = false;
            AnimationFinished?.Invoke(animation.Id);
        }

        /// <summary>Loads an imported SpriteLoop asset synchronously on the main thread.</summary>
        /// <param name="asset">Imported .spla archive.</param>
        public bool Load(SpriteLoopAsset asset)
        {
            return asset != null && Load(asset.Bytes);
        }

        /// <summary>Loads complete .spla ZIP bytes synchronously on the main thread.</summary>
        /// <param name="bytes">Complete archive bytes.</param>
        public bool Load(byte[] bytes)
        {
            Unload();
            try
            {
                if (bytes == null || bytes.Length == 0)
                    throw new InvalidDataException("The SPLA archive is empty.");

                using (var stream = new MemoryStream(bytes, false))
                using (var archive = new ZipArchive(stream, ZipArchiveMode.Read, false))
                {
                    var entries = new Dictionary<string, ZipArchiveEntry>(StringComparer.Ordinal);
                    foreach (var entry in archive.Entries)
                    {
                        if (string.IsNullOrEmpty(entry.Name))
                            continue;
                        entries[NormalizeArchivePath(entry.FullName)] = entry;
                    }
                    if (!entries.TryGetValue("manifest.json", out var manifestEntry))
                        throw new InvalidDataException("The SPLA archive has no manifest.json file.");
                    string manifestJson;
                    using (var reader = new StreamReader(manifestEntry.Open()))
                        manifestJson = reader.ReadToEnd();
                    _manifest = JsonConvert.DeserializeObject<SplaManifest>(manifestJson);
                    if (_manifest == null || _manifest.Format != "spla" || _manifest.Version != 1)
                        throw new InvalidDataException("Only SPLA manifest version 1 is supported.");
                    if (_manifest.Canvas == null || _manifest.Canvas.Width <= 0f || _manifest.Canvas.Height <= 0f)
                        throw new InvalidDataException("The SPLA canvas dimensions are invalid.");
                    _manifest.Parts = _manifest.Parts ?? Array.Empty<SplaPart>();
                    _manifest.Variants = _manifest.Variants ?? Array.Empty<SplaVariant>();
                    _manifest.States = _manifest.States ?? Array.Empty<SplaState>();
                    _manifest.Skins = _manifest.Skins ?? Array.Empty<SplaSkin>();
                    _manifest.Animations = _manifest.Animations ?? Array.Empty<SplaAnimation>();

                    var assetPaths = new HashSet<string>(StringComparer.Ordinal);
                    foreach (var part in _manifest.Parts)
                    {
                        part.Asset = NormalizeArchivePath(part.Asset);
                        if (!string.IsNullOrEmpty(part.Asset))
                            assetPaths.Add(part.Asset);
                    }
                    foreach (var variant in _manifest.Variants)
                    {
                        variant.Asset = NormalizeArchivePath(variant.Asset);
                        if (!string.IsNullOrEmpty(variant.Asset))
                            assetPaths.Add(variant.Asset);
                    }
                    foreach (var assetPath in assetPaths)
                    {
                        if (!entries.TryGetValue(assetPath, out var imageEntry))
                            throw new InvalidDataException($"The SPLA image '{assetPath}' is missing.");
                        byte[] imageBytes;
                        using (var imageStream = imageEntry.Open())
                        using (var imageBuffer = new MemoryStream())
                        {
                            imageStream.CopyTo(imageBuffer);
                            imageBytes = imageBuffer.ToArray();
                        }
                        var texture = new Texture2D(2, 2, TextureFormat.RGBA32, false)
                        {
                            name = Path.GetFileNameWithoutExtension(assetPath),
                            filterMode = _filterMode,
                            wrapMode = TextureWrapMode.Clamp
                        };
#if UNITY_EDITOR
                        if (!Application.IsPlaying(gameObject))
                            texture.hideFlags = HideFlags.HideAndDontSave;
#endif
                        if (!ImageConversion.LoadImage(texture, imageBytes, false))
                        {
                            DestroyUnityObject(texture);
                            throw new InvalidDataException($"The SPLA image '{assetPath}' is not a supported texture.");
                        }
                        _textures.Add(assetPath, texture);
                    }
                }

                var shader = Shader.Find("Sprites/Default");
                if (shader == null)
                    throw new InvalidOperationException("Unity shader 'Sprites/Default' was not found.");
                _material = new Material(shader) { name = "SpriteLoop Runtime Material" };
                _partsRootObj = new GameObject("SpriteLoop Parts");
                _partsRootObj.transform.SetParent(transform, false);
                _mesh = new Mesh { name = "SpriteLoop Combined Mesh" };
#if UNITY_EDITOR
                if (!Application.IsPlaying(gameObject))
                {
                    _material.hideFlags = HideFlags.HideAndDontSave;
                    _partsRootObj.hideFlags = HideFlags.HideAndDontSave;
                    _mesh.hideFlags = HideFlags.HideAndDontSave;
                }
#endif
                _mesh.MarkDynamic();
                _partsRootObj.AddComponent<MeshFilter>().sharedMesh = _mesh;
                _renderer = _partsRootObj.AddComponent<MeshRenderer>();
                _renderer.sharedMaterial = _material;
                _renderer.sortingLayerName = _sortingLayer;
                _renderer.sortingOrder = _sortingOrder;
                _renderer.enabled = false;

                _parts = new PartRuntime[_manifest.Parts.Length];
                for (var index = 0; index < _manifest.Parts.Length; index++)
                {
                    var part = _manifest.Parts[index];
                    if (string.IsNullOrWhiteSpace(part.Id))
                        throw new InvalidDataException($"SPLA part {index} has no ID.");
                    AddLookup(_partLookup, part.Id, index);
                    AddLookup(_partLookup, part.Key, index);
                    AddLookup(_partLookup, part.Name, index);
                    var partObj = new GameObject($"Part {(!string.IsNullOrEmpty(part.Name) ? part.Name : part.Id)}");
                    partObj.transform.SetParent(_partsRootObj.transform, false);
#if UNITY_EDITOR
                    if (!Application.IsPlaying(gameObject))
                        partObj.hideFlags = HideFlags.HideAndDontSave;
#endif
                    var pivot = part.Pivot ?? new SplaPoint();
                    var texture = !string.IsNullOrEmpty(part.Asset) && _textures.TryGetValue(part.Asset, out var baseTexture) ? baseTexture : null;
                    _parts[index] = new PartRuntime(part, index, partObj.transform,
                        new ImageRuntime(texture, part.Width, part.Height, pivot.X, pivot.Y, 0f, 0));
                }

                _variants = new ImageRuntime[_manifest.Variants.Length];
                for (var index = 0; index < _manifest.Variants.Length; index++)
                {
                    var variant = _manifest.Variants[index];
                    var partIndex = Resolve(_partLookup, variant.Part);
                    if (partIndex < 0 || !_textures.TryGetValue(variant.Asset, out var texture))
                        continue;
                    variant.PartIndex = partIndex;
                    var part = _manifest.Parts[partIndex];
                    var pivot = part.Pivot ?? new SplaPoint();
                    _variants[index] = new ImageRuntime(texture,
                        variant.Width > 0f ? variant.Width : part.Width,
                        variant.Height > 0f ? variant.Height : part.Height,
                        pivot.X - variant.OffsetX,
                        pivot.Y - variant.OffsetY,
                        variant.Rotation,
                        variant.ZOffset);
                    AddLookup(_variantLookup, variant.Id, index);
                    AddLookup(_variantLookup, variant.Key, index);
                    AddLookup(_variantLookup, variant.Name, index);
                }

                _skins = new SkinRuntime[Mathf.Max(1, _manifest.Skins.Length)];
                if (_manifest.Skins.Length == 0)
                {
                    _skins[0] = new SkinRuntime("default", "Default");
                    AddLookup(_skinLookup, "default", 0);
                }
                for (var index = 0; index < _manifest.Skins.Length; index++)
                {
                    var skin = _manifest.Skins[index];
                    var runtimeSkin = new SkinRuntime(string.IsNullOrEmpty(skin.Id) ? $"skin_{index}" : skin.Id,
                        string.IsNullOrEmpty(skin.Name) ? skin.Id : skin.Name);
                    foreach (var pair in skin.Parts ?? new Dictionary<string, SplaSkinOverride>())
                    {
                        var partIndex = Resolve(_partLookup, pair.Key);
                        if (partIndex < 0)
                            continue;
                        var sourceOverride = pair.Value ?? new SplaSkinOverride();
                        var runtimeOverride = new SkinOverrideRuntime
                        {
                            HasVisible = sourceOverride.Visible.HasValue,
                            Visible = sourceOverride.Visible ?? true,
                            VariantIndex = ResolveVariantForPart(partIndex, sourceOverride.Variant)
                        };
                        foreach (var stateVariant in sourceOverride.States ?? new Dictionary<string, string>())
                        {
                            var stateIndex = ResolveStateForPart(partIndex, stateVariant.Key);
                            var variantIndex = ResolveVariantForPart(partIndex, stateVariant.Value);
                            if (stateIndex >= 0 && variantIndex >= 0)
                                runtimeOverride.StateVariants[stateIndex] = variantIndex;
                        }
                        runtimeSkin.Overrides[partIndex] = runtimeOverride;
                    }
                    _skins[index] = runtimeSkin;
                    AddLookup(_skinLookup, runtimeSkin.Id, index);
                    AddLookup(_skinLookup, runtimeSkin.Name, index);
                }

                for (var index = 0; index < _manifest.Animations.Length; index++)
                {
                    var animation = _manifest.Animations[index];
                    animation.Frames = animation.Frames ?? Array.Empty<SplaFrame>();
                    Array.Sort(animation.Frames, (left, right) => left.Index.CompareTo(right.Index));
                    foreach (var frame in animation.Frames)
                    {
                        frame.Parts = frame.Parts ?? Array.Empty<SplaFramePart>();
                        frame.Events = frame.Events ?? Array.Empty<SplaEvent>();
                    }
                    AddLookup(_animationLookup, animation.Id, index);
                    AddLookup(_animationLookup, animation.Name, index);
                }

                // Pack every base and variant image once so the combined character uses one material and draw call.
                var images = new List<ImageRuntime>(_parts.Length + _variants.Length);
                foreach (var part in _parts)
                    if (part.BaseImage.Texture != null)
                        images.Add(part.BaseImage);
                foreach (var variant in _variants)
                    if (variant?.Texture != null)
                        images.Add(variant);
                var atlasTextures = new List<Texture2D>();
                var atlasTextureIndices = new Dictionary<Texture2D, int>();
                foreach (var image in images)
                {
                    if (atlasTextureIndices.ContainsKey(image.Texture))
                        continue;
                    atlasTextureIndices.Add(image.Texture, atlasTextures.Count);
                    atlasTextures.Add(image.Texture);
                }
                _atlas = new Texture2D(2, 2, TextureFormat.RGBA32, false)
                {
                    name = "SpriteLoop Runtime Atlas",
                    filterMode = _filterMode,
                    wrapMode = TextureWrapMode.Clamp
                };
#if UNITY_EDITOR
                if (!Application.IsPlaying(gameObject))
                    _atlas.hideFlags = HideFlags.HideAndDontSave;
#endif
                Rect[] atlasRects;
                if (atlasTextures.Count == 0)
                {
                    _atlas.SetPixel(0, 0, Color.clear);
                    _atlas.Apply(false, true);
                    atlasRects = Array.Empty<Rect>();
                }
                else
                {
                    var maximumAtlasSize = Mathf.Max(256, Mathf.Min(_maximumAtlasSize, SystemInfo.maxTextureSize));
                    atlasRects = _atlas.PackTextures(atlasTextures.ToArray(), 2, maximumAtlasSize, false);
                    _atlas.filterMode = _filterMode;
                    _atlas.wrapMode = TextureWrapMode.Clamp;
                    foreach (var image in images)
                    {
                        image.Uv = atlasRects[atlasTextureIndices[image.Texture]];
                        image.Texture = null;
                    }
                    _atlas.Apply(false, true);
                }
                foreach (var texture in _textures.Values)
                    DestroyUnityObject(texture);
                _textures.Clear();
                _material.SetTexture(MAIN_TEXTURE_ID, _atlas);
                _material.SetColor(COLOR_ID, Color.white);

                var vertexCount = _parts.Length * 4;
                _vertices = new Vector3[vertexCount];
                _uvs = new Vector2[vertexCount];
                _colors = new Color32[vertexCount];
                _triangles = new int[_parts.Length * 6];
                if (vertexCount > ushort.MaxValue)
                    _mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
                _mesh.vertices = _vertices;
                _mesh.uv = _uvs;
                _mesh.colors32 = _colors;
                _mesh.SetIndices(Array.Empty<int>(), MeshTopology.Triangles, 0, false);

                _skinIndex = 0;
                var animationReference = string.IsNullOrWhiteSpace(_defaultAnimation) && _manifest.Animations.Length > 0
                    ? _manifest.Animations[0].Id
                    : _defaultAnimation;
                if (!string.IsNullOrEmpty(animationReference))
                {
                    Play(animationReference, _defaultLoopMode, true);
                    if (!_autoplay)
                    {
                        _playing = false;
                        _paused = false;
                    }
                }
                Loaded?.Invoke();
                return true;
            }
            catch (Exception exception)
            {
                var message = $"SpriteLoop could not load: {exception.Message}";
                Unload();
                Debug.LogError(message, this);
                LoadFailed?.Invoke(message);
                return false;
            }
        }

        /// <summary>Loads a .spla archive from an absolute filesystem path.</summary>
        /// <param name="absolutePath">Absolute readable file path.</param>
        public bool LoadFile(string absolutePath)
        {
            try
            {
                return Load(File.ReadAllBytes(absolutePath));
            }
            catch (Exception exception)
            {
                var message = $"SpriteLoop could not read '{absolutePath}': {exception.Message}";
                Debug.LogError(message, this);
                LoadFailed?.Invoke(message);
                return false;
            }
        }

        /// <summary>Loads a .spla file relative to Unity's StreamingAssets folder.</summary>
        /// <param name="relativePath">Relative StreamingAssets path.</param>
        public IEnumerator LoadFromStreamingAssets(string relativePath)
        {
            var path = Path.Combine(Application.streamingAssetsPath, relativePath).Replace("\\", "/");
            if (!path.Contains("://"))
                path = new Uri(path).AbsoluteUri;
            using (var request = UnityWebRequest.Get(path))
            {
                yield return request.SendWebRequest();
#if UNITY_2020_2_OR_NEWER
                if (request.result != UnityWebRequest.Result.Success)
#else
                if (request.isNetworkError || request.isHttpError)
#endif
                {
                    var message = $"SpriteLoop could not read '{relativePath}': {request.error}";
                    Debug.LogError(message, this);
                    LoadFailed?.Invoke(message);
                    yield break;
                }
                Load(request.downloadHandler.data);
            }
        }

        /// <summary>Destroys the loaded package and all generated Unity resources.</summary>
        public void Unload()
        {
            _playing = false;
            _paused = false;
            _elapsed = 0f;
            _animationIndex = -1;
            _frameIndex = -1;
            _skinIndex = 0;
            _manualVariants.Clear();
            _controlOverrides.Clear();
            _animationLookup.Clear();
            _partLookup.Clear();
            _skinLookup.Clear();
            _variantLookup.Clear();
            foreach (var texture in _textures.Values)
                DestroyUnityObject(texture);
            _textures.Clear();
            DestroyUnityObject(_mesh);
            DestroyUnityObject(_atlas);
            DestroyUnityObject(_material);
            DestroyUnityObject(_partsRootObj);
            _mesh = null;
            _atlas = null;
            _material = null;
            _renderer = null;
            _partsRootObj = null;
            _parts = Array.Empty<PartRuntime>();
            _variants = Array.Empty<ImageRuntime>();
            _skins = Array.Empty<SkinRuntime>();
            _vertices = Array.Empty<Vector3>();
            _uvs = Array.Empty<Vector2>();
            _colors = Array.Empty<Color32>();
            _triangles = Array.Empty<int>();
            _drawParts.Clear();
            _manifest = null;
        }

        /// <summary>Starts an animation selected by ID or display name.</summary>
        /// <param name="animationReference">Animation ID or name.</param>
        /// <param name="loopMode">Loop override for this playback.</param>
        /// <param name="restart">Restart when the requested animation is already selected.</param>
        public bool Play(string animationReference, SpriteLoopLoopMode loopMode = SpriteLoopLoopMode.FROM_PACKAGE, bool restart = true)
        {
            if (_manifest == null)
                return false;
            var index = Resolve(_animationLookup, animationReference);
            if (index < 0)
                return false;
            var changed = index != _animationIndex;
            _animationIndex = index;
            _loopMode = loopMode;
            if (changed || restart)
            {
                _elapsed = 0f;
                ApplyFrame(0, false);
            }
            _playing = true;
            _paused = false;
            return true;
        }

        public void Stop()
        {
            _playing = false;
            _paused = false;
        }

        public void Pause()
        {
            if (!_playing)
                return;
            _playing = false;
            _paused = true;
        }

        public void Resume()
        {
            if (!_paused || _animationIndex < 0)
                return;
            _paused = false;
            _playing = true;
        }

        /// <summary>Seeks to a zero-based frame in the current animation.</summary>
        /// <param name="frame">Destination frame.</param>
        /// <param name="emitEvents">Emit authored events on the destination frame.</param>
        public void SetFrame(int frame, bool emitEvents = false)
        {
            if (_animationIndex < 0)
                return;
            var animation = _manifest.Animations[_animationIndex];
            if (animation.Frames.Length == 0)
                return;
            var clamped = Mathf.Clamp(frame, 0, animation.Frames.Length - 1);
            _elapsed = clamped / Mathf.Max(0.0001f, animation.Fps);
            ApplyFrame(clamped, emitEvents);
        }

        /// <summary>Seeks to a time in the current animation.</summary>
        /// <param name="seconds">Playback seconds.</param>
        /// <param name="emitEvents">Emit authored events on the destination frame.</param>
        public void SetTime(float seconds, bool emitEvents = false)
        {
            if (_animationIndex < 0)
                return;
            var animation = _manifest.Animations[_animationIndex];
            if (animation.Frames.Length == 0)
                return;
            var fps = Mathf.Max(0.0001f, animation.Fps);
            var duration = animation.Frames.Length / fps;
            _elapsed = EffectiveLoop(animation) ? Mathf.Repeat(seconds, duration) : Mathf.Clamp(seconds, 0f, duration);
            ApplyFrame(Mathf.Clamp(Mathf.FloorToInt(_elapsed * fps), 0, animation.Frames.Length - 1), emitEvents);
        }

        /// <summary>Selects a skin by ID or display name.</summary>
        /// <param name="skinReference">Skin ID or name.</param>
        public bool SetSkin(string skinReference)
        {
            var index = Resolve(_skinLookup, skinReference);
            if (index < 0)
                return false;
            _skinIndex = index;
            if (_frameIndex >= 0)
                ApplyFrame(_frameIndex, false);
            return true;
        }

        /// <summary>Overrides one part with a variant.</summary>
        /// <param name="partReference">Part ID, key, or name.</param>
        /// <param name="variantReference">Variant ID, key, or name.</param>
        public bool SetVariant(string partReference, string variantReference)
        {
            var partIndex = Resolve(_partLookup, partReference);
            var variantIndex = ResolveVariantForPart(partIndex, variantReference);
            if (partIndex < 0 || variantIndex < 0)
                return false;
            _manualVariants[partIndex] = variantIndex;
            if (_frameIndex >= 0)
                ApplyFrame(_frameIndex, false);
            return true;
        }

        /// <summary>Clears a manual variant override from one part.</summary>
        /// <param name="partReference">Part ID, key, or name.</param>
        public bool ClearVariant(string partReference)
        {
            var partIndex = Resolve(_partLookup, partReference);
            if (partIndex < 0 || !_manualVariants.Remove(partIndex))
                return false;
            if (_frameIndex >= 0)
                ApplyFrame(_frameIndex, false);
            return true;
        }

        public void ClearVariants()
        {
            _manualVariants.Clear();
            if (_frameIndex >= 0)
                ApplyFrame(_frameIndex, false);
        }

        /// <summary>Offsets or replaces one control's authored position in SpriteLoop canvas pixels.</summary>
        /// <param name="partReference">Part or empty-control ID, key, or name.</param>
        /// <param name="position">Offset or absolute canvas position, measured from the canvas top-left.</param>
        /// <param name="mode">Whether the value modifies or replaces the authored position.</param>
        public bool SetControlPosition(string partReference, Vector2 position,
            SpriteLoopTransformOverrideMode mode = SpriteLoopTransformOverrideMode.OFFSET)
        {
            var partIndex = Resolve(_partLookup, partReference);
            if (partIndex < 0)
                return false;
            if (!_controlOverrides.TryGetValue(partIndex, out var transformOverride))
            {
                transformOverride = new PartTransformOverrideRuntime();
                _controlOverrides.Add(partIndex, transformOverride);
            }
            transformOverride.HasPosition = true;
            transformOverride.PositionMode = mode == SpriteLoopTransformOverrideMode.ABSOLUTE
                ? SpriteLoopTransformOverrideMode.ABSOLUTE
                : SpriteLoopTransformOverrideMode.OFFSET;
            transformOverride.Position = position;
            if (_frameIndex >= 0)
                ApplyFrame(_frameIndex, false);
            return true;
        }

        /// <summary>Offsets or replaces one control's authored angle in SpriteLoop degrees.</summary>
        /// <param name="partReference">Part or empty-control ID, key, or name.</param>
        /// <param name="angle">Angle offset or absolute authored angle in degrees.</param>
        /// <param name="mode">Whether the value modifies or replaces the authored angle.</param>
        public bool SetControlAngle(string partReference, float angle,
            SpriteLoopTransformOverrideMode mode = SpriteLoopTransformOverrideMode.OFFSET)
        {
            var partIndex = Resolve(_partLookup, partReference);
            if (partIndex < 0)
                return false;
            if (!_controlOverrides.TryGetValue(partIndex, out var transformOverride))
            {
                transformOverride = new PartTransformOverrideRuntime();
                _controlOverrides.Add(partIndex, transformOverride);
            }
            transformOverride.HasAngle = true;
            transformOverride.AngleMode = mode == SpriteLoopTransformOverrideMode.ABSOLUTE
                ? SpriteLoopTransformOverrideMode.ABSOLUTE
                : SpriteLoopTransformOverrideMode.OFFSET;
            transformOverride.Angle = angle;
            if (_frameIndex >= 0)
                ApplyFrame(_frameIndex, false);
            return true;
        }

        /// <summary>Multiplies or replaces one control's authored scale.</summary>
        /// <param name="partReference">Part or empty-control ID, key, or name.</param>
        /// <param name="scale">Scale multiplier or absolute authored scale.</param>
        /// <param name="mode">Whether the value modifies or replaces the authored scale.</param>
        public bool SetControlScale(string partReference, Vector2 scale,
            SpriteLoopTransformOverrideMode mode = SpriteLoopTransformOverrideMode.OFFSET)
        {
            var partIndex = Resolve(_partLookup, partReference);
            if (partIndex < 0)
                return false;
            if (!_controlOverrides.TryGetValue(partIndex, out var transformOverride))
            {
                transformOverride = new PartTransformOverrideRuntime();
                _controlOverrides.Add(partIndex, transformOverride);
            }
            transformOverride.HasScale = true;
            transformOverride.ScaleMode = mode == SpriteLoopTransformOverrideMode.ABSOLUTE
                ? SpriteLoopTransformOverrideMode.ABSOLUTE
                : SpriteLoopTransformOverrideMode.OFFSET;
            transformOverride.Scale = scale;
            if (_frameIndex >= 0)
                ApplyFrame(_frameIndex, false);
            return true;
        }

        /// <summary>Restores every authored transform channel for one control.</summary>
        /// <param name="partReference">Part or empty-control ID, key, or name.</param>
        public bool ClearControlOverride(string partReference)
        {
            var partIndex = Resolve(_partLookup, partReference);
            if (partIndex < 0 || !_controlOverrides.Remove(partIndex))
                return false;
            if (_frameIndex >= 0)
                ApplyFrame(_frameIndex, false);
            return true;
        }

        /// <summary>Restores authored transforms for every control.</summary>
        public void ClearControlOverrides()
        {
            if (_controlOverrides.Count == 0)
                return;
            _controlOverrides.Clear();
            if (_frameIndex >= 0)
                ApplyFrame(_frameIndex, false);
        }

        /// <summary>Gets one control's authored, override, and final SpriteLoop canvas transform.</summary>
        /// <param name="partReference">Part or empty-control ID, key, or name.</param>
        /// <param name="state">Current transform state when the control exists in the displayed frame.</param>
        public bool TryGetControlTransformState(string partReference, out SpriteLoopControlTransformState state)
        {
            state = default;
            var partIndex = Resolve(_partLookup, partReference);
            if (partIndex < 0 || _animationIndex < 0 || _frameIndex < 0)
                return false;
            var frame = _manifest.Animations[_animationIndex].Frames[_frameIndex];
            foreach (var framePart in frame.Parts)
            {
                if (Resolve(_partLookup, framePart.Part) != partIndex)
                    continue;
                _controlOverrides.TryGetValue(partIndex, out var transformOverride);
                state = new SpriteLoopControlTransformState(
                    new Vector2(framePart.X, framePart.Y),
                    framePart.Rotation,
                    new Vector2(framePart.ScaleX, framePart.ScaleY),
                    transformOverride);
                return true;
            }
            return false;
        }

        /// <summary>Gets the generated transform located at a part's final overridden pivot.</summary>
        /// <param name="partReference">Part ID, key, or name.</param>
        /// <param name="partTransform">Generated part transform when found.</param>
        public bool TryGetPartTransform(string partReference, out Transform partTransform)
        {
            var index = Resolve(_partLookup, partReference);
            partTransform = index >= 0 && index < _parts.Length ? _parts[index].Transform : null;
            return partTransform != null;
        }

        private void ApplyFrame(int frameIndex, bool emitEvents)
        {
            if (_animationIndex < 0 || _mesh == null)
                return;
            var animation = _manifest.Animations[_animationIndex];
            if (frameIndex < 0 || frameIndex >= animation.Frames.Length)
                return;

            var frame = animation.Frames[frameIndex];
            var pixelsPerUnit = Mathf.Max(0.0001f, _pixelsPerUnit);
            _drawParts.Clear();
            foreach (var framePart in frame.Parts)
            {
                var partIndex = Resolve(_partLookup, framePart.Part);
                if (partIndex < 0)
                    continue;
                var part = _parts[partIndex];
                var visible = part.Source.Visible;
                var image = part.BaseImage;
                SkinOverrideRuntime skinOverride = null;
                if (_skinIndex >= 0 && _skinIndex < _skins.Length)
                    _skins[_skinIndex].Overrides.TryGetValue(partIndex, out skinOverride);
                if (skinOverride != null && skinOverride.HasVisible)
                    visible = skinOverride.Visible;

                var variantIndex = -1;
                if (_manualVariants.TryGetValue(partIndex, out var manualVariant))
                    variantIndex = manualVariant;
                else if (skinOverride != null && skinOverride.StateVariants.TryGetValue(
                    ResolveStateForPart(partIndex, ActiveStateReference(framePart)), out var stateVariant))
                    variantIndex = stateVariant;
                else if (skinOverride != null)
                    variantIndex = skinOverride.VariantIndex;
                if (variantIndex >= 0 && variantIndex < _variants.Length && _variants[variantIndex] != null)
                    image = _variants[variantIndex];

                _controlOverrides.TryGetValue(partIndex, out var transformOverride);
                var transformState = new SpriteLoopControlTransformState(
                    new Vector2(framePart.X, framePart.Y),
                    framePart.Rotation,
                    new Vector2(framePart.ScaleX, framePart.ScaleY),
                    transformOverride);
                part.Transform.localPosition = new Vector3(
                    (transformState.FinalPosition.x - _manifest.Canvas.Width * 0.5f) / pixelsPerUnit,
                    (_manifest.Canvas.Height * 0.5f - transformState.FinalPosition.y) / pixelsPerUnit,
                    0f);
                part.Transform.localRotation = Quaternion.Euler(0f, 0f, -(transformState.FinalAngle + image.Rotation));
                part.Transform.localScale = new Vector3(transformState.FinalScale.x, transformState.FinalScale.y, 1f);
                if (!visible || image.Uv.width <= 0f || image.Uv.height <= 0f || framePart.Opacity <= 0f)
                    continue;

                var left = -image.PivotX;
                var top = -image.PivotY;
                var right = image.Width - image.PivotX;
                var bottom = image.Height - image.PivotY;
                var skewX = Mathf.Tan(framePart.SkewX * Mathf.Deg2Rad);
                var skewY = Mathf.Tan(framePart.SkewY * Mathf.Deg2Rad);
                var rotation = -(transformState.FinalAngle + image.Rotation) * Mathf.Deg2Rad;
                var cosRotation = Mathf.Cos(rotation);
                var sinRotation = Mathf.Sin(rotation);
                var vertexOffset = partIndex * 4;
                for (var corner = 0; corner < 4; corner++)
                {
                    var scaledX = (corner == 0 || corner == 3 ? left : right) * transformState.FinalScale.x;
                    var scaledY = (corner < 2 ? top : bottom) * transformState.FinalScale.y;
                    var localX = (scaledX + skewX * scaledY) / pixelsPerUnit;
                    var localY = -(skewY * scaledX + scaledY) / pixelsPerUnit;
                    _vertices[vertexOffset + corner] = new Vector3(
                        part.Transform.localPosition.x + cosRotation * localX - sinRotation * localY,
                        part.Transform.localPosition.y + sinRotation * localX + cosRotation * localY,
                        0f);
                }
                _uvs[vertexOffset] = new Vector2(image.Uv.xMin, image.Uv.yMax);
                _uvs[vertexOffset + 1] = new Vector2(image.Uv.xMax, image.Uv.yMax);
                _uvs[vertexOffset + 2] = new Vector2(image.Uv.xMax, image.Uv.yMin);
                _uvs[vertexOffset + 3] = new Vector2(image.Uv.xMin, image.Uv.yMin);
                var tint = framePart.Tint;
                var color = new Color(
                    tint != null && tint.Length > 0 ? tint[0] : 1f,
                    tint != null && tint.Length > 1 ? tint[1] : 1f,
                    tint != null && tint.Length > 2 ? tint[2] : 1f,
                    Mathf.Clamp01(framePart.Opacity));
                for (var corner = 0; corner < 4; corner++)
                    _colors[vertexOffset + corner] = color;
                part.SortOrder = (part.Source.DrawOrder ?? part.Index) + framePart.ZOffset + image.ZOffset;
                _drawParts.Add(part);
            }
            _drawParts.Sort((left, right) => left.SortOrder != right.SortOrder
                ? left.SortOrder.CompareTo(right.SortOrder)
                : left.Index.CompareTo(right.Index));
            for (var drawIndex = 0; drawIndex < _drawParts.Count; drawIndex++)
            {
                var vertexOffset = _drawParts[drawIndex].Index * 4;
                var triangleOffset = drawIndex * 6;
                _triangles[triangleOffset] = vertexOffset;
                _triangles[triangleOffset + 1] = vertexOffset + 1;
                _triangles[triangleOffset + 2] = vertexOffset + 2;
                _triangles[triangleOffset + 3] = vertexOffset;
                _triangles[triangleOffset + 4] = vertexOffset + 2;
                _triangles[triangleOffset + 5] = vertexOffset + 3;
            }
            _mesh.vertices = _vertices;
            _mesh.uv = _uvs;
            _mesh.colors32 = _colors;
            _mesh.SetIndices(_triangles, 0, _drawParts.Count * 6, MeshTopology.Triangles, 0, false);
            _mesh.RecalculateBounds();
            _renderer.enabled = _drawParts.Count > 0;
            _frameIndex = frameIndex;
            FrameChanged?.Invoke(frameIndex);
            if (emitEvents)
                EmitFrameEvents(animation, frameIndex);
        }

        private void EmitFrameEvents(SplaAnimation animation, int frameIndex)
        {
            if (!_emitEvents || frameIndex < 0 || frameIndex >= animation.Frames.Length)
                return;
            var frame = animation.Frames[frameIndex];
            foreach (var sourceEvent in frame.Events)
                AnimationEvent?.Invoke(new SpriteLoopAnimationEvent(animation.Id, frameIndex, frame.SourceFrame,
                    sourceEvent.Name ?? "", sourceEvent.Data ?? ""));
        }

        private bool EffectiveLoop(SplaAnimation animation)
        {
            return _loopMode == SpriteLoopLoopMode.LOOP || (_loopMode == SpriteLoopLoopMode.FROM_PACKAGE && animation.Loop);
        }

        private int ResolveVariantForPart(int partIndex, string reference)
        {
            var index = Resolve(_variantLookup, reference);
            return partIndex >= 0 && index >= 0 && index < _manifest.Variants.Length && _manifest.Variants[index].PartIndex == partIndex ? index : -1;
        }

        private int ResolveStateForPart(int partIndex, string reference)
        {
            if (partIndex < 0 || string.IsNullOrWhiteSpace(reference))
                return -1;
            for (var index = 0; index < _manifest.States.Length; index++)
            {
                var state = _manifest.States[index];
                if (Resolve(_partLookup, state.Part) != partIndex)
                    continue;
                if (string.Equals(state.Id, reference, StringComparison.Ordinal) ||
                    string.Equals(state.Key, reference, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(state.Name, reference, StringComparison.OrdinalIgnoreCase))
                    return index;
            }
            return -1;
        }

        private static string ActiveStateReference(SplaFramePart framePart)
        {
            if (framePart.State is JObject stateObject)
            {
                var current = StringToken(stateObject["current"] ?? stateObject["id"]);
                var next = StringToken(stateObject["next"]);
                var mix = Mathf.Clamp01(stateObject["mix"]?.Value<float>() ?? framePart.StateMix);
                return mix >= 0.5f && !string.IsNullOrWhiteSpace(next) ? next : current;
            }
            var state = framePart.State?.Type == JTokenType.String ? framePart.State.Value<string>() : "";
            return Mathf.Clamp01(framePart.StateMix) >= 0.5f && !string.IsNullOrWhiteSpace(framePart.NextState)
                ? framePart.NextState
                : state;
        }

        private static string StringToken(JToken token)
        {
            return token?.Type == JTokenType.String ? token.Value<string>() : "";
        }

        private static int Resolve(Dictionary<string, int> lookup, string reference)
        {
            return !string.IsNullOrWhiteSpace(reference) && lookup.TryGetValue(reference, out var index) ? index : -1;
        }

        private static void AddLookup(Dictionary<string, int> lookup, string reference, int index)
        {
            if (!string.IsNullOrWhiteSpace(reference) && !lookup.ContainsKey(reference))
                lookup.Add(reference, index);
        }

        private static string NormalizeArchivePath(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
                return "";
            var result = new List<string>();
            foreach (var segment in path.Replace('\\', '/').Split('/'))
            {
                if (string.IsNullOrEmpty(segment) || segment == ".")
                    continue;
                if (segment == "..")
                    throw new InvalidDataException($"Unsafe SPLA archive path '{path}'.");
                result.Add(segment);
            }
            return string.Join("/", result);
        }

        private void OnValidate()
        {
            // Keep runtime settings valid without creating or destroying editor objects here.
            _pixelsPerUnit = Mathf.Max(0.0001f, _pixelsPerUnit);
            _playbackRate = Mathf.Max(0f, _playbackRate);
            _maximumAtlasSize = Mathf.Max(256, _maximumAtlasSize);
#if UNITY_EDITOR
            if (!Application.IsPlaying(gameObject))
                _editorPreviewDirty = true;
#endif
        }

        private void DestroyUnityObject(UnityEngine.Object value)
        {
            if (value == null)
                return;
            if (Application.IsPlaying(gameObject))
                Destroy(value);
            else
                DestroyImmediate(value);
        }

        private sealed class PartRuntime
        {
            public SplaPart Source { get; }
            public int Index { get; }
            public Transform Transform { get; }
            public ImageRuntime BaseImage { get; }
            public int SortOrder { get; set; }

            public PartRuntime(SplaPart source, int index, Transform transform, ImageRuntime baseImage)
            {
                Source = source;
                Index = index;
                Transform = transform;
                BaseImage = baseImage;
            }
        }

        private sealed class ImageRuntime
        {
            public Texture2D Texture { get; set; }
            public Rect Uv { get; set; }
            public float Width { get; }
            public float Height { get; }
            public float PivotX { get; }
            public float PivotY { get; }
            public float Rotation { get; }
            public int ZOffset { get; }

            public ImageRuntime(Texture2D texture, float width, float height, float pivotX, float pivotY, float rotation, int zOffset)
            {
                Texture = texture;
                Width = width;
                Height = height;
                PivotX = pivotX;
                PivotY = pivotY;
                Rotation = rotation;
                ZOffset = zOffset;
            }
        }

        private sealed class SkinRuntime
        {
            public string Id { get; }
            public string Name { get; }
            public Dictionary<int, SkinOverrideRuntime> Overrides { get; } = new Dictionary<int, SkinOverrideRuntime>();

            public SkinRuntime(string id, string name)
            {
                Id = id;
                Name = name;
            }
        }

        private sealed class SkinOverrideRuntime
        {
            public int VariantIndex { get; set; } = -1;
            public bool HasVisible { get; set; }
            public bool Visible { get; set; } = true;
            public Dictionary<int, int> StateVariants { get; } = new Dictionary<int, int>();
        }

        private sealed class SplaManifest
        {
            [JsonProperty("format")] public string Format { get; set; }
            [JsonProperty("version")] public int Version { get; set; }
            [JsonProperty("name")] public string Name { get; set; }
            [JsonProperty("canvas")] public SplaCanvas Canvas { get; set; }
            [JsonProperty("parts")] public SplaPart[] Parts { get; set; }
            [JsonProperty("variants")] public SplaVariant[] Variants { get; set; }
            [JsonProperty("states")] public SplaState[] States { get; set; }
            [JsonProperty("skins")] public SplaSkin[] Skins { get; set; }
            [JsonProperty("animations")] public SplaAnimation[] Animations { get; set; }
        }

        private sealed class SplaCanvas
        {
            [JsonProperty("width")] public float Width { get; set; }
            [JsonProperty("height")] public float Height { get; set; }
        }

        private sealed class SplaPoint
        {
            [JsonProperty("x")] public float X { get; set; }
            [JsonProperty("y")] public float Y { get; set; }
        }

        private sealed class SplaPart
        {
            [JsonProperty("id")] public string Id { get; set; }
            [JsonProperty("key")] public string Key { get; set; }
            [JsonProperty("name")] public string Name { get; set; }
            [JsonProperty("kind")] public string Kind { get; set; }
            [JsonProperty("asset")] public string Asset { get; set; }
            [JsonProperty("width")] public float Width { get; set; }
            [JsonProperty("height")] public float Height { get; set; }
            [JsonProperty("pivot")] public SplaPoint Pivot { get; set; }
            [JsonProperty("drawOrder")] public int? DrawOrder { get; set; }
            [JsonProperty("visible")] public bool Visible { get; set; } = true;
        }

        private sealed class SplaVariant
        {
            [JsonProperty("id")] public string Id { get; set; }
            [JsonProperty("key")] public string Key { get; set; }
            [JsonProperty("name")] public string Name { get; set; }
            [JsonProperty("part")] public string Part { get; set; }
            [JsonProperty("asset")] public string Asset { get; set; }
            [JsonProperty("width")] public float Width { get; set; }
            [JsonProperty("height")] public float Height { get; set; }
            [JsonProperty("offsetX")] public float OffsetX { get; set; }
            [JsonProperty("offsetY")] public float OffsetY { get; set; }
            [JsonProperty("rotation")] public float Rotation { get; set; }
            [JsonProperty("zOffset")] public int ZOffset { get; set; }
            [JsonIgnore] public int PartIndex { get; set; } = -1;
        }

        private sealed class SplaState
        {
            [JsonProperty("id")] public string Id { get; set; }
            [JsonProperty("key")] public string Key { get; set; }
            [JsonProperty("name")] public string Name { get; set; }
            [JsonProperty("part")] public string Part { get; set; }
        }

        private sealed class SplaSkin
        {
            [JsonProperty("id")] public string Id { get; set; }
            [JsonProperty("name")] public string Name { get; set; }
            [JsonProperty("parts")] public Dictionary<string, SplaSkinOverride> Parts { get; set; }
        }

        private sealed class SplaSkinOverride
        {
            [JsonProperty("variant")] public string Variant { get; set; }
            [JsonProperty("visible")] public bool? Visible { get; set; }
            [JsonProperty("states")] public Dictionary<string, string> States { get; set; }
        }

        private sealed class SplaAnimation
        {
            [JsonProperty("id")] public string Id { get; set; }
            [JsonProperty("name")] public string Name { get; set; }
            [JsonProperty("fps")] public float Fps { get; set; } = 24f;
            [JsonProperty("loop")] public bool Loop { get; set; }
            [JsonProperty("frames")] public SplaFrame[] Frames { get; set; }
        }

        private sealed class SplaFrame
        {
            [JsonProperty("index")] public int Index { get; set; }
            [JsonProperty("sourceFrame")] public int SourceFrame { get; set; }
            [JsonProperty("parts")] public SplaFramePart[] Parts { get; set; }
            [JsonProperty("events")] public SplaEvent[] Events { get; set; }
        }

        private sealed class SplaFramePart
        {
            [JsonProperty("part")] public string Part { get; set; }
            [JsonProperty("zOffset")] public int ZOffset { get; set; }
            [JsonProperty("x")] public float X { get; set; }
            [JsonProperty("y")] public float Y { get; set; }
            [JsonProperty("rotation")] public float Rotation { get; set; }
            [JsonProperty("skewX")] public float SkewX { get; set; }
            [JsonProperty("skewY")] public float SkewY { get; set; }
            [JsonProperty("scaleX")] public float ScaleX { get; set; } = 1f;
            [JsonProperty("scaleY")] public float ScaleY { get; set; } = 1f;
            [JsonProperty("opacity")] public float Opacity { get; set; } = 1f;
            [JsonProperty("tint")] public float[] Tint { get; set; }
            [JsonProperty("state")] public JToken State { get; set; }
            [JsonProperty("nextState")] public string NextState { get; set; }
            [JsonProperty("stateMix")] public float StateMix { get; set; }
        }

        private sealed class SplaEvent
        {
            [JsonProperty("name")] public string Name { get; set; }
            [JsonProperty("data")] public string Data { get; set; }
        }
    }
}
