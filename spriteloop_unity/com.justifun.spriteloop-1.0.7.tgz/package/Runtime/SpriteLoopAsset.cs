using System;
using UnityEngine;

namespace Justifun.SpriteLoop
{
    /// <summary>Imported byte content for one SpriteLoop .spla package.</summary>
    public sealed class SpriteLoopAsset : ScriptableObject
    {
        [SerializeField, HideInInspector] private byte[] _bytes = Array.Empty<byte>();

        public byte[] Bytes => _bytes;

        /// <summary>Replaces the stored SPLA archive bytes.</summary>
        /// <param name="bytes">Complete .spla ZIP data.</param>
        public void SetBytes(byte[] bytes)
        {
            _bytes = bytes ?? Array.Empty<byte>();
        }
    }
}

