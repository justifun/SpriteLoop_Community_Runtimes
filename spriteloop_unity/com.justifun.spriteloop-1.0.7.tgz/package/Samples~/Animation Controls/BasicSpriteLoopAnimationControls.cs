using UnityEngine;

namespace Justifun.SpriteLoop.Samples
{
    /// <summary>Exposes basic SpriteLoop playback controls for scripts and Unity UI events.</summary>
    [RequireComponent(typeof(SpriteLoopPlayer))]
    public sealed class BasicSpriteLoopAnimationControls : MonoBehaviour
    {
        [Tooltip("Animation ID or display name played after the SPLA package loads.")]
        [SerializeField] private string _startingAnimation = "idle";

        private SpriteLoopPlayer _player;

        private void Awake()
        {
            // Cache the required player on this GameObject.
            _player = GetComponent<SpriteLoopPlayer>();
        }

        private void OnEnable()
        {
            // Start immediately for an existing package or wait for loading to finish.
            _player.Loaded += PlayStartingAnimation;
            if (_player.IsLoaded)
                PlayStartingAnimation();
        }

        private void OnDisable()
        {
            // Stop receiving callbacks while this controller is disabled.
            _player.Loaded -= PlayStartingAnimation;
        }

        /// <summary>Plays an animation using its exported loop setting.</summary>
        /// <param name="animationReference">Animation ID or display name.</param>
        public void Play(string animationReference)
        {
            _player.Play(animationReference);
        }

        /// <summary>Plays an animation and forces it to loop.</summary>
        /// <param name="animationReference">Animation ID or display name.</param>
        public void PlayLooping(string animationReference)
        {
            _player.Play(animationReference, SpriteLoopLoopMode.LOOP);
        }

        /// <summary>Plays an animation once.</summary>
        /// <param name="animationReference">Animation ID or display name.</param>
        public void PlayOnce(string animationReference)
        {
            _player.Play(animationReference, SpriteLoopLoopMode.NO_LOOP);
        }

        /// <summary>Pauses on the current frame.</summary>
        public void Pause()
        {
            _player.Pause();
        }

        /// <summary>Continues from a paused frame.</summary>
        public void Resume()
        {
            _player.Resume();
        }

        /// <summary>Toggles between paused and playing.</summary>
        public void TogglePause()
        {
            if (_player.IsPaused)
                _player.Resume();
            else
                _player.Pause();
        }

        /// <summary>Stops while leaving the current frame visible.</summary>
        public void Stop()
        {
            _player.Stop();
        }

        /// <summary>Changes the playback speed multiplier.</summary>
        /// <param name="rate">Zero or a positive speed multiplier.</param>
        public void SetPlaybackRate(float rate)
        {
            _player.PlaybackRate = rate;
        }

        /// <summary>Seeks to a zero-based frame.</summary>
        /// <param name="frame">Destination frame.</param>
        public void SetFrame(int frame)
        {
            _player.SetFrame(frame);
        }

        private void PlayStartingAnimation()
        {
            if (!string.IsNullOrWhiteSpace(_startingAnimation))
                _player.Play(_startingAnimation);
        }
    }
}
