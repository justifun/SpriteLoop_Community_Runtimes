using UnityEngine;

namespace Justifun.SpriteLoop.Samples
{
    /// <summary>Moves a GameObject in world-space XY using the arrow keys.</summary>
    public sealed class SpriteLoopArrowKeyMovement : MonoBehaviour
    {
        [Tooltip("Movement speed in Unity units per second.")]
        [Min(0f)] [SerializeField] private float _speed = 3f;

        private void Update()
        {
            // Read the four arrow keys and keep diagonal movement at the same speed.
            var direction = Vector2.zero;
#if ENABLE_INPUT_SYSTEM
            var keyboard = UnityEngine.InputSystem.Keyboard.current;
            if (keyboard == null)
                return;
            if (keyboard.leftArrowKey.isPressed)
                direction.x -= 1f;
            if (keyboard.rightArrowKey.isPressed)
                direction.x += 1f;
            if (keyboard.downArrowKey.isPressed)
                direction.y -= 1f;
            if (keyboard.upArrowKey.isPressed)
                direction.y += 1f;
#else
            if (Input.GetKey(KeyCode.LeftArrow))
                direction.x -= 1f;
            if (Input.GetKey(KeyCode.RightArrow))
                direction.x += 1f;
            if (Input.GetKey(KeyCode.DownArrow))
                direction.y -= 1f;
            if (Input.GetKey(KeyCode.UpArrow))
                direction.y += 1f;
#endif
            transform.position += (Vector3)(direction.normalized * (_speed * Time.deltaTime));
        }
    }
}
